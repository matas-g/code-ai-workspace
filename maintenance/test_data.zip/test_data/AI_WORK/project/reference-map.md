# Sample reference map

Synthetic sources for the prepared test projects. Links work here and after copying this overlay into a generated workspace with default internal names. Follow only sources relevant to the selected task.

| Topic | Authoritative source path/link | Owner | Last checked |
|---|---|---|---|
| Architecture and default behavior | [Sample architecture](../../COMPANY_DOCS/engineering-handbook/architecture.md) | Synthetic engineering team | 1 November 2026 |
| Internal project name and writing style | [Sample writing guidelines](../../COMPANY_DOCS/company-guidelines/writing-style.md) | Synthetic documentation team | 1 November 2026 |
| Console implementation | [main.py](../../MAIN_PROJECT/hello-console/main.py) | Synthetic application team | 1 November 2026 |
| Website implementation | [index.html](../../MAIN_PROJECT/hello-website/index.html) | Synthetic application team | 1 November 2026 |
| Reference greeting function | [greeting.py](../../OTHER_PROJECTS/greeting-library/greeting.py) | Synthetic reference team | 1 November 2026 |
| Reference CLI | [hello.py](../../OTHER_PROJECTS/hello-cli/hello.py) | Synthetic reference team | 1 November 2026 |

The dates record fixture-source review; they do not certify Copilot loading or manual test results.
