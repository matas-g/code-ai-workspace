# Project overview — synthetic greeting projects

Prepared context for six synthetic Code-AI test repositories. Paths use the default internal directory names.

## Purpose

Practice multi-repository context lookup, local ticket workflows, reviews and workspace management with tiny offline examples. These are invented projects and requirements, with no real company data or external services.

## Repositories and responsibilities

| Repository | Role |
|---|---|
| [MAIN_PROJECT/hello-console](../../MAIN_PROJECT/hello-console/README.md) | Python console application |
| [MAIN_PROJECT/hello-website](../../MAIN_PROJECT/hello-website/README.md) | Static HTML page |
| [OTHER_PROJECTS/greeting-library](../../OTHER_PROJECTS/greeting-library/README.md) | Reference Python greeting function |
| [OTHER_PROJECTS/hello-cli](../../OTHER_PROJECTS/hello-cli/README.md) | Reference Python CLI with an optional name argument |
| [COMPANY_DOCS/engineering-handbook](../../COMPANY_DOCS/engineering-handbook/README.md) | Sample architecture and behavior requirements |
| [COMPANY_DOCS/company-guidelines](../../COMPANY_DOCS/company-guidelines/README.md) | Sample internal project name and writing guidelines |

## Data flow and external interfaces

All projects are independent. There are no imports or runtime services between repositories. Python examples require Python 3.9+ and no third-party packages; the website opens directly in a browser. Default MAIN output is `Hello, world!`.

## Existing behavior and important constraints

The console's `greeting(name)` returns text; only its script entry point prints. Preserve existing defaults unless the selected task requests a change. Confirm detailed requirements using the [reference map](reference-map.md) and original source files. Treat the DOCS repositories as reference material unless a selected task explicitly includes documentation changes.

## Git naming conventions

These editable sample defaults apply when the selected repository has no more specific rule. They do not authorize branch creation or commits.

### Branch names

Use `feature/<ticket-id>_<short_description>` or `bugfix/<ticket-id>_<short_description>`; choose `feature` when unspecified. Preserve ticket spelling, use lowercase descriptions with underscores, and omit the ticket segment when there is no ticket. Use a GitHub issue's number without `#` in a branch name.

Examples: `feature/DEMO-101_add_uppercase_flag`, `bugfix/42_handle_empty_input`, `feature/update_setup_guide`.

### Commit messages

Use `<ticket-id> <Change area>. <Short summary>`. Preserve ticket references (including `#` for GitHub issues), list multiple references before the change area, and omit the ticket segment when none applies. The change area has 1–4 words; start the summary with a capitalized action verb and omit its final period. Follow repository-specific formats for release, merge, revert or automated commits.

Examples: `DEMO-101 Console greeting. Add uppercase flag`, `#42 Input validation. Handle empty input`, `Documentation. Update setup guide`.

### Repository-specific exceptions

No exceptions are defined in the initial synthetic repositories. Recheck the selected repository's guidance before suggesting or using a name.

## Sources and verification date

Originally prepared on 24 October 2026; reviewed against these fixture files on 1 November 2026. See the [reference map](reference-map.md). This is example context, not a record of a completed manual VS Code or Copilot test.
