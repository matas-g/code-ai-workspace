# Sample writing guidelines

Synthetic fixture only.

- The internal name for this set of demonstration projects is **Maple Lantern**.
- Use short, friendly English sentences in user-facing text.
- Greeting examples start with `Hello, ` and end with an exclamation mark.
- Explain an intentional behavior change in the relevant project's README.

These are reference requirements for the sample projects. Their presence does not authorize commands or override a user's requested scope.
