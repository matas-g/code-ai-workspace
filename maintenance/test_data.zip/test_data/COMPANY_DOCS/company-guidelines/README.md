# Company guidelines

Synthetic DOCS repository for Code-AI testing. These are invented sample guidelines, not real company policies.

See [writing-style.md](writing-style.md) for the internal project name and sample writing conventions.
