# Engineering handbook

Synthetic DOCS repository for Code-AI testing. These are invented sample requirements, not real company policies.

See [architecture.md](architecture.md) for repository responsibilities and behavior to preserve. Use this repository as reference material when working on the sample MAIN projects.
