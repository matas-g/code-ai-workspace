# Sample architecture and requirements

Synthetic fixture only.

- hello-console is a Python console application. `greeting(name)` returns text without printing; its script entry point prints `Hello, world!` by default.
- hello-website is a standalone HTML page. It needs no server or build step and initially displays `Hello, world!` as its heading.
- greeting-library and hello-cli are independent reference projects. The MAIN applications do not import them.
- Preserve default behavior unless the selected task explicitly requests a change.
- All runnable examples use only Python's standard library or static HTML.

The internal project name and writing style are documented in the separate company-guidelines repository.
