# Code-AI test data

This archive contains six small synthetic repositories with local Git histories and populated project context. No dependencies or remotes are needed.

## Use

1. Generate a fresh Code-AI workspace with the default internal directory names and an empty repository inventory.
2. Copy **all contents** of this extracted `test_data/` folder into the generated workspace, including the repositories' hidden `.git` directories. **Merge folders and replace matching files; do not replace the entire `AI_WORK` folder.** Keep its generated guides, tools, skills and `.framework` records. If your file manager cannot merge folders, copy the two context files into `AI_WORK/project/` separately, then copy the other top-level items.
3. Run the generated refresh launcher and approve repository registration and workspace updates.
4. Open the saved workspace under `ide_configs/` in VS Code. Use the generated Copilot and daily guides for normal work.

Only `AI_WORK/project/overview.md` and `reference-map.md` replace existing generated files. Use a fresh destination when resetting your tests. If you customized internal folder names, adjust the extracted folders and context links before copying.

## Contents

| Group | Repositories |
|---|---|
| MAIN_PROJECT | hello-console, hello-website |
| OTHER_PROJECTS | greeting-library, hello-cli |
| COMPANY_DOCS | engineering-handbook, company-guidelines |

All six are independent Git repositories on `main`, each with one initial commit and no remotes. Initial commits use the synthetic identity `Code-AI Test Fixture <fixtures@example.invalid>`; future commits use your normal Git configuration.

The Python examples need Python 3.9+ and only its standard library. Run them from their own folders with `python3 -I -S -B main.py`, `python3 -I -S -B greeting.py`, or `python3 -I -S -B hello.py Ada`. The website opens directly in a browser.

Record actual results and usability friction in the development repository's `maintenance/MANUAL_TESTS.md`. Preparing these files does not prove VS Code or Copilot behavior.
