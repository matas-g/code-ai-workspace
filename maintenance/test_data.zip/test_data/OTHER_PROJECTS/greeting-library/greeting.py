"""A tiny reference library for manual framework testing."""


def greet(name):
    return "Hello, " + name + "!"


if __name__ == "__main__":
    print(greet("Ada"))
