# Greeting library

Synthetic OTHER repository for Code-AI testing. No dependencies; Python 3.9+.

`greet(name)` returns a string without printing. Run `python3 -I -S -B greeting.py` from this folder for a demonstration: `Hello, Ada!`

This is reference code only; the MAIN examples do not import it. Try asking Copilot to compare its greeting function with hello-console without changing either repository.
