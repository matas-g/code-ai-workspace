"""A tiny command-line application for manual framework testing."""
import argparse


def main():
    parser = argparse.ArgumentParser(description="Print a friendly greeting.")
    parser.add_argument("name", nargs="?", default="world")
    args = parser.parse_args()
    print("Hello, " + args.name + "!")


if __name__ == "__main__":
    main()
