# Hello CLI

Synthetic OTHER repository for Code-AI testing. No dependencies; Python 3.9+.

Run `python3 -I -S -B hello.py` for `Hello, world!`, or `python3 -I -S -B hello.py Ada` for `Hello, Ada!`. Use `--help` to see the command arguments.

This command is independent of the MAIN projects and greeting-library. A useful test change is to add an optional uppercase greeting flag while preserving default behavior.
