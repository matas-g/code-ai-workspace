# Hello console

Synthetic MAIN repository for Code-AI testing. No dependencies; Python 3.9+.

Run `python3 -I -S -B main.py` from this folder. Expected output: `Hello, world!`

`greeting(name)` returns a greeting; it does not print. The script entry point prints the default greeting. Keep that separation when making a small test change. The companion hello-website repository is independent.
