"""A tiny console application for manual framework testing."""


def greeting(name="world"):
    return "Hello, " + name + "!"


if __name__ == "__main__":
    print(greeting())
