# Hello website

Synthetic MAIN repository for Code-AI testing. Open `index.html` directly in a browser. No server, build tools or dependencies are needed.

Expected heading: `Hello, world!` Try changing the heading in your copied repository and reviewing the diff. This site has no runtime dependency on the other sample projects.
