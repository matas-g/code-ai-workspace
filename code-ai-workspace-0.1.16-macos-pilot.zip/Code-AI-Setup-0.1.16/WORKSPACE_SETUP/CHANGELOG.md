# Changelog

## 0.1.16 — 28 October 2026

- Describe ide_configs as holding saved workspaces and other IDE-specific configuration files in the generated root README. This wording change does not add automatic configuration support for other IDEs.
- Refresh release metadata, source hashes and the pilot archive. Existing generated workspaces are not automatically updated.

## 0.1.15 — 25 October 2026

- Rename the generated AI working guide from README.md to DAILY_WORK.md and rename its source template to match. Keep the development-root README.md and COPILOT_GUIDE.md filenames.
- Update navigation and Copilot orientation links, setup messages, required-file inventory, release mappings and documentation together. New installations use the descriptive filename; existing generated workspaces are not automatically renamed or upgraded.

## 0.1.14 — 25 October 2026

- Rewrite the generated root README, AI working README and COPILOT_GUIDE.md around getting started, daily tasks and Copilot setup respectively.
- Replace repeated prose with short steps, task tables and links; remove optional extension suggestions, internal helper/template details and duplicated command explanations.
- Retain refresh/preservation rules, backup and recovery, direct-command fallback and honest instruction/skill verification limits. No daily command behavior changes; existing generated workspaces are not automatically updated.

## 0.1.13 — 24 October 2026

- Generalize project origins, adoption plans and security guidance for public distribution while preserving the design and runtime behavior.
- Anonymize historical manual-test evidence and retain its original scope and pending checks.
- Exclude local metadata, caches and development fixtures from Git publication; rebuild the manifest and pilot archive.

## 0.1.12 — 24 October 2026

- Standardize confirmations: `[Y/n]` continues from settings to the read-only preview, while `[y/N]` protects creation and both refresh write steps. Enter follows the displayed default; EOF always cancels.
- Show `[y/N/remove-missing]` only when missing registrations exist; cleanup still requires the explicit keyword. Accept short/full answers, repeat invalid input and retain no-change skipping and final `[q/quit]` behavior.
- Update guides, behavioral coverage and pending manual checks. Existing generated workspaces are not automatically updated.

## 0.1.11 — 24 October 2026

- Rename all five framework skills, their folders and slash commands with the `ca-` prefix. Update shared helper paths, required-file inventory, release mappings, tests and current guides together.
- Establish `ca-` as the naming rule for future framework and framework-maintenance skills, with release and strict validation checks. Unrelated audited skills retain their own names.
- Record renamed-skill discovery as a fresh manual check; preserve earlier results under the original names. Existing generated workspaces are not automatically upgraded.

## 0.1.10 — 24 October 2026

- Capture task details supplied to jira-ticket-init in a new brief through the optional `--description` argument. Preserve literal text, keep unknown requirements unrecorded and retain existing brief edits on repeat initialization.
- Add jira-ticket-archive and jira-ticket-restore skills using the existing deterministic ticket mover. Both operate only on local ticket folders and preserve their contents.
- Validate/package all five skills, update daily guides and cover prompt capture, custom templates, repeat preservation and relocated direct-command workflows.
- Record the reported successful original three-skill and finished-workflow checks separately from pending verification of these new capabilities. Existing generated trees are not automatically upgraded.

## 0.1.9 — 24 October 2026

- Format validation/audit results with an overall status, severity counts and separate ordered sections for errors, warnings, manual checks and notes.
- Group editable-file changes with a clear explanation that intentional repository registrations and context updates are normal. Use the same formatter for setup validation; preserve complete paths, wrapping and plain-text readability.
- Confirm saved audit report locations. Preserve JSON data, saved JSON format and command exit codes; other noninteractive commands retain their JSON output.
- Add diagnostic-output coverage and manual terminal checks. Existing generated installations are not automatically updated.

## 0.1.8 — 23 October 2026

- Rename the generated daily tools to `workspace_manager.py`, `terminal_output_formatter.py` and `vscode_workspace_updater.py`, with matching source filenames.
- Update helper loading, refresh launchers, required-file inventory, release mappings, skills, command examples and tests to use the new names. The setup-only `scripts/workspace.py` remains the initializer.
- Existing installations are not automatically renamed or upgraded; new installations use the updated filenames.

## 0.1.7 — 22 October 2026

- Generate a concise AI Work/.github/copilot-instructions.md orientation with relative, configurable links to project context, tickets, knowledge and daily tools. Existing repository/global instructions and settings are untouched.
- Include an independent COPILOT_GUIDE.md for context preparation, cross-root/mode discovery checks, References/debug evidence and explicit-attachment fallback. Automatic Copilot loading remains a manual check.
- Validate and audit the new files/resources; orientation edits are user-owned and preserved by refresh.
- Maintain MANUAL_TESTS.md at the development-project root, excluded from the package and generated workspaces. Native Windows, GUI and actual Copilot loading remain pending.

## 0.1.6 — 21 October 2026

- Align registration statuses and VS Code workspace paths in consistent preview columns. Preserve full names and use indented detail lines when a terminal is too narrow for columns.
- Show a prominent No changes message for up-to-date phases; omit the change legend when there are no registration rows. Warnings remain visible.
- Simplify refresh prompts to Action [yes/no] or Action [yes/remove-missing/no]. Short y/n answers remain accepted.

## 0.1.5 — 21 October 2026

- Added independent macOS/Windows refresh_vscode_workspace launchers in generated development folders, with two previews/approvals and final q/quit retention.
- Discover immediate child folders under configured repository groups; register new folders enabled with exact folder-name labels. Preserve existing IDs, custom labels and selections. Ordinary folders need no Git marker.
- Retain missing entries by default; explicit remove-missing cleans configuration only. Renames/moves are missing old entries plus new registrations.
- Refresh only the workspace folders value. Preserve settings, other properties and surrounding JSONC bytes; ordinary workspace edits no longer fail whole-file drift validation.
- Shared console presentation, concurrent-edit checks, documented direct preview/apply alternatives and expanded behavioral tests.
- No automatic upgrade of existing generated trees. Native Windows and actual Copilot discovery remain pending.

## 0.1.4 — 21 October 2026

Pilot release.

- Repository root labels use automatic `MAIN ·`, `OTHER ·` and `DOCS ·` prefixes. Groups stay together in a predictable order; AI Work and Knowledge retain their names.
- Grouped navigation extensions remain an optional manual experiment if prefixes prove inconvenient.
- Default repository folders are `MAIN_PROJECT` and `OTHER_PROJECTS`, configured with `primary_repositories` and `other_repositories`.
- One enclosing `Code-AI-Setup-<version>/` folder keeps the README, launchers and setup sources together on extraction.
- VS Code displays the AI working folder as **AI Work** and the knowledge folder as **Knowledge**.
- Offline, new-directory setup with settings review, file preview and validation; Python 3.9+ and standard library only.
- Clickable macOS/Windows launchers and a short setup guide.
- Configurable development folder, repository groups and independent VS Code helper filename.
- Portable daily notes, knowledge, local skills and ticket tools, independent of installer files.
- Relative links, structural validation and drift protection. Other IDEs use shared files/tools with manual project setup.
- Native Windows and actual Copilot skill discovery remain pending; see VALIDATION_REPORT.md.
